import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { SidebarProvider, SidebarTrigger } from "@/components/ui/sidebar";
import { useToast } from "@/hooks/use-toast";
import { User } from "@supabase/supabase-js";
import { PersonalDataTab } from "./dashboard/PersonalDataTab";
import { SecurityTab } from "./dashboard/SecurityTab";
import { FinancesTab } from "./dashboard/FinancesTab";
import { PartnerProgramTab } from "./dashboard/PartnerProgramTab";
import { DashboardSidebar } from "./DashboardSidebar";
import { Settings } from "lucide-react";

const Dashboard = () => {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState("personal");
  const navigate = useNavigate();
  const { toast } = useToast();

  useEffect(() => {
    const checkAuth = async () => {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) {
        navigate("/");
        return;
      }
      setUser(session.user);
      setLoading(false);
    };

    checkAuth();

    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      (event, session) => {
        if (event === 'SIGNED_OUT' || !session) {
          navigate("/");
        } else {
          setUser(session.user);
        }
      }
    );

    return () => subscription.unsubscribe();
  }, [navigate]);

  const renderActiveTab = () => {
    if (!user) return null;
    
    switch (activeTab) {
      case "personal":
        return <PersonalDataTab user={user} />;
      case "security":
        return <SecurityTab user={user} />;
      case "finances":
        return <FinancesTab user={user} />;
      case "partner":
        return <PartnerProgramTab />;
      default:
        return <PersonalDataTab user={user} />;
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-primary mx-auto"></div>
          <p className="mt-4 text-muted-foreground">Загрузка...</p>
        </div>
      </div>
    );
  }

  if (!user) {
    return null;
  }

  return (
    <SidebarProvider>
      <div className="min-h-screen flex w-full">
        <main className="flex-1 p-4">
          <div className="max-w-4xl mx-auto">
            <div className="flex items-center justify-between mb-6">
              <div>
                <h1 className="text-3xl font-bold">Панель управления</h1>
                <p className="text-muted-foreground">Управляйте своим аккаунтом и настройками</p>
              </div>
              <SidebarTrigger className="flex items-center gap-2">
                <Settings className="h-4 w-4" />
                Меню
              </SidebarTrigger>
            </div>
            
            <Card>
              <CardContent className="p-6">
                {renderActiveTab()}
              </CardContent>
            </Card>
          </div>
        </main>
        
        <DashboardSidebar 
          user={user} 
          activeTab={activeTab} 
          onTabChange={setActiveTab} 
        />
      </div>
    </SidebarProvider>
  );
};

export default Dashboard;