import { Card } from "@/components/ui/card";
import { TrendingUp, TrendingDown } from "lucide-react";

const exchangeRates = [
  {
    from: "BTC",
    to: "RUB",
    fromIcon: "₿",
    toIcon: "₽",
    rate: "2,890,000.00",
    change: "+2.5%",
    trend: "up",
    volume: "4.2M ₽"
  },
  {
    from: "USDT",
    to: "RUB", 
    fromIcon: "₮",
    toIcon: "₽",
    rate: "96.45",
    change: "+0.1%",
    trend: "up",
    volume: "12.8M ₽"
  },
  {
    from: "ETH",
    to: "RUB",
    fromIcon: "Ξ",
    toIcon: "₽",
    rate: "180,250.00",
    change: "+1.8%",
    trend: "up",
    volume: "2.1M ₽"
  },
  {
    from: "BNB",
    to: "RUB",
    fromIcon: "🔶",
    toIcon: "₽",
    rate: "15,420.00",
    change: "-0.5%",
    trend: "down",
    volume: "850K ₽"
  },
  {
    from: "ADA",
    to: "RUB",
    fromIcon: "🔺",
    toIcon: "₽",
    rate: "38.50",
    change: "+3.2%",
    trend: "up",
    volume: "420K ₽"
  },
  {
    from: "XRP",
    to: "RUB",
    fromIcon: "🌊",
    toIcon: "₽",
    rate: "52.80",
    change: "+1.1%",
    trend: "up",
    volume: "680K ₽"
  }
];

export const RatesTable = () => {
  return (
    <section id="rates" className="py-20 bg-background">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold mb-4">
            Актуальные{" "}
            <span className="text-gradient-gold">курсы</span>
          </h2>
          <p className="text-lg text-muted-foreground">
            Курсы обновляются каждые 30 секунд
          </p>
        </div>

        <Card className="bg-card/80 backdrop-blur-sm border-crypto-gray-dark">
          <div className="p-6">
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-crypto-gray-dark">
                    <th className="text-left py-4 px-2 font-semibold text-muted-foreground">
                      Валютная пара
                    </th>
                    <th className="text-right py-4 px-2 font-semibold text-muted-foreground">
                      Курс
                    </th>
                    <th className="text-right py-4 px-2 font-semibold text-muted-foreground">
                      Изменение 24ч
                    </th>
                    <th className="text-right py-4 px-2 font-semibold text-muted-foreground">
                      Объем
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {exchangeRates.map((rate, index) => (
                    <tr
                      key={`${rate.from}-${rate.to}`}
                      className="border-b border-crypto-gray-dark/50 hover:bg-crypto-dark-elevated/50 transition-colors cursor-pointer"
                    >
                      <td className="py-4 px-2">
                        <div className="flex items-center space-x-3">
                          <div className="flex items-center space-x-1">
                            <span className="text-2xl">{rate.fromIcon}</span>
                            <span className="text-sm text-muted-foreground">→</span>
                            <span className="text-2xl">{rate.toIcon}</span>
                          </div>
                          <div>
                            <div className="font-semibold">
                              {rate.from}/{rate.to}
                            </div>
                            <div className="text-sm text-muted-foreground">
                              {rate.from} к {rate.to}
                            </div>
                          </div>
                        </div>
                      </td>
                      <td className="py-4 px-2 text-right">
                        <div className="font-mono font-semibold text-lg">
                          {rate.rate} ₽
                        </div>
                      </td>
                      <td className="py-4 px-2 text-right">
                        <div className={`flex items-center justify-end space-x-1 ${
                          rate.trend === "up" ? "text-crypto-success" : "text-crypto-error"
                        }`}>
                          {rate.trend === "up" ? (
                            <TrendingUp className="w-4 h-4" />
                          ) : (
                            <TrendingDown className="w-4 h-4" />
                          )}
                          <span className="font-semibold">{rate.change}</span>
                        </div>
                      </td>
                      <td className="py-4 px-2 text-right">
                        <div className="text-muted-foreground">
                          {rate.volume}
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </Card>

        <div className="mt-8 text-center">
          <p className="text-sm text-muted-foreground">
            Курсы указаны без учета комиссии. Итоговая сумма рассчитывается при создании заявки.
          </p>
        </div>
      </div>
    </section>
  );
};