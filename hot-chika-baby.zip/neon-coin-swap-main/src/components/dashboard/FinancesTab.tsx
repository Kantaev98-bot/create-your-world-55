import { useState, useEffect } from "react";
import { User } from "@supabase/supabase-js";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import { Loader2, Plus, CreditCard, Wallet, Trash2 } from "lucide-react";

interface FinancialAccount {
  id: string;
  account_type: "card" | "wallet" | "account";
  account_name: string;
  account_number?: string;
  currency: string;
  balance: number;
  is_active: boolean;
  created_at: string;
}

interface Transaction {
  id: string;
  transaction_type: "exchange" | "deposit" | "withdrawal";
  from_currency: string;
  to_currency: string;
  from_amount: number;
  to_amount: number;
  exchange_rate?: number;
  status: "pending" | "processing" | "completed" | "cancelled" | "failed";
  created_at: string;
}

interface OpenOrder {
  id: string;
  from_currency: string;
  to_currency: string;
  amount: number;
  target_rate: number;
  status: "active" | "cancelled" | "executed";
  created_at: string;
}

interface FinancesTabProps {
  user: User;
}

export const FinancesTab = ({ user }: FinancesTabProps) => {
  const [accounts, setAccounts] = useState<FinancialAccount[]>([]);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [openOrders, setOpenOrders] = useState<OpenOrder[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isAddingAccount, setIsAddingAccount] = useState(false);
  const [showAddDialog, setShowAddDialog] = useState(false);
  const [newAccount, setNewAccount] = useState<{
    account_type: "card" | "wallet" | "account";
    account_name: string;
    account_number: string;
    currency: string;
  }>({
    account_type: "card",
    account_name: "",
    account_number: "",
    currency: "RUB",
  });
  const { toast } = useToast();

  useEffect(() => {
    loadFinancialData();
  }, [user.id]);

  const loadFinancialData = async () => {
    setIsLoading(true);
    try {
      // Load financial accounts
      const { data: accountsData, error: accountsError } = await supabase
        .from("financial_accounts")
        .select("*")
        .eq("user_id", user.id)
        .order("created_at", { ascending: false });

      if (accountsError) {
        console.error("Error loading accounts:", accountsError);
      } else {
        setAccounts((accountsData || []) as FinancialAccount[]);
      }

      // Load transactions
      const { data: transactionsData, error: transactionsError } = await supabase
        .from("transactions")
        .select("*")
        .eq("user_id", user.id)
        .order("created_at", { ascending: false })
        .limit(20);

      if (transactionsError) {
        console.error("Error loading transactions:", transactionsError);
      } else {
        setTransactions((transactionsData || []) as Transaction[]);
      }

      // Load open orders
      const { data: ordersData, error: ordersError } = await supabase
        .from("open_orders")
        .select("*")
        .eq("user_id", user.id)
        .eq("status", "active")
        .order("created_at", { ascending: false });

      if (ordersError) {
        console.error("Error loading orders:", ordersError);
      } else {
        setOpenOrders((ordersData || []) as OpenOrder[]);
      }
    } catch (error) {
      console.error("Error:", error);
      toast({
        variant: "destructive",
        title: "Ошибка",
        description: "Не удалось загрузить финансовые данные",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleAddAccount = async () => {
    if (!newAccount.account_name || !newAccount.currency) {
      toast({
        variant: "destructive",
        title: "Ошибка",
        description: "Заполните все обязательные поля",
      });
      return;
    }

    setIsAddingAccount(true);
    try {
      const { error } = await supabase
        .from("financial_accounts")
        .insert({
          user_id: user.id,
          ...newAccount,
        });

      if (error) {
        console.error("Error adding account:", error);
        toast({
          variant: "destructive",
          title: "Ошибка",
          description: "Не удалось добавить счет",
        });
      } else {
        toast({
          title: "Успешно!",
          description: "Счет добавлен",
        });
        setShowAddDialog(false);
        setNewAccount({
          account_type: "card",
          account_name: "",
          account_number: "",
          currency: "RUB",
        });
        loadFinancialData();
      }
    } catch (error) {
      console.error("Error:", error);
      toast({
        variant: "destructive",
        title: "Ошибка",
        description: "Произошла ошибка при добавлении счета",
      });
    } finally {
      setIsAddingAccount(false);
    }
  };

  const handleDeleteAccount = async (accountId: string) => {
    try {
      const { error } = await supabase
        .from("financial_accounts")
        .delete()
        .eq("id", accountId);

      if (error) {
        console.error("Error deleting account:", error);
        toast({
          variant: "destructive",
          title: "Ошибка",
          description: "Не удалось удалить счет",
        });
      } else {
        toast({
          title: "Успешно!",
          description: "Счет удален",
        });
        loadFinancialData();
      }
    } catch (error) {
      console.error("Error:", error);
      toast({
        variant: "destructive",
        title: "Ошибка",
        description: "Произошла ошибка при удалении счета",
      });
    }
  };

  const getAccountIcon = (type: string) => {
    switch (type) {
      case "card":
        return <CreditCard className="h-4 w-4" />;
      case "wallet":
        return <Wallet className="h-4 w-4" />;
      default:
        return <CreditCard className="h-4 w-4" />;
    }
  };

  const getStatusBadge = (status: string) => {
    const statusMap = {
      pending: { label: "Ожидание", variant: "secondary" as const },
      processing: { label: "Обработка", variant: "default" as const },
      completed: { label: "Завершено", variant: "default" as const },
      cancelled: { label: "Отменено", variant: "destructive" as const },
      failed: { label: "Ошибка", variant: "destructive" as const },
      active: { label: "Активный", variant: "default" as const },
      executed: { label: "Исполнен", variant: "default" as const },
    };

    const statusInfo = statusMap[status as keyof typeof statusMap] || { label: status, variant: "secondary" as const };
    return <Badge variant={statusInfo.variant}>{statusInfo.label}</Badge>;
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-48">
        <Loader2 className="h-8 w-8 animate-spin" />
      </div>
    );
  }

  return (
    <Tabs defaultValue="accounts" className="w-full">
      <TabsList className="grid w-full grid-cols-3">
        <TabsTrigger value="accounts">Счета и карты</TabsTrigger>
        <TabsTrigger value="transactions">История операций</TabsTrigger>
        <TabsTrigger value="orders">Открытые ордера</TabsTrigger>
      </TabsList>

      <TabsContent value="accounts" className="space-y-4">
        <Card>
          <CardHeader>
            <div className="flex justify-between items-center">
              <div>
                <CardTitle>Привязанные счета и карты</CardTitle>
                <CardDescription>
                  Управляйте вашими финансовыми счетами
                </CardDescription>
              </div>
              <Dialog open={showAddDialog} onOpenChange={setShowAddDialog}>
                <DialogTrigger asChild>
                  <Button>
                    <Plus className="h-4 w-4 mr-2" />
                    Добавить
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Добавить новый счет</DialogTitle>
                    <DialogDescription>
                      Заполните информацию о новом счете или карте
                    </DialogDescription>
                  </DialogHeader>
                  <div className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="accountType">Тип счета</Label>
                      <Select
                        value={newAccount.account_type}
                        onValueChange={(value: "card" | "wallet" | "account") =>
                          setNewAccount(prev => ({ ...prev, account_type: value }))
                        }
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="card">Банковская карта</SelectItem>
                          <SelectItem value="wallet">Криптокошелек</SelectItem>
                          <SelectItem value="account">Банковский счет</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="accountName">Название счета</Label>
                      <Input
                        id="accountName"
                        value={newAccount.account_name}
                        onChange={(e) =>
                          setNewAccount(prev => ({ ...prev, account_name: e.target.value }))
                        }
                        placeholder="Моя карта Сбербанк"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="accountNumber">Номер счета/карты (необязательно)</Label>
                      <Input
                        id="accountNumber"
                        value={newAccount.account_number}
                        onChange={(e) =>
                          setNewAccount(prev => ({ ...prev, account_number: e.target.value }))
                        }
                        placeholder="**** **** **** 1234"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="currency">Валюта</Label>
                      <Select
                        value={newAccount.currency}
                        onValueChange={(value) =>
                          setNewAccount(prev => ({ ...prev, currency: value }))
                        }
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="RUB">RUB - Российский рубль</SelectItem>
                          <SelectItem value="USD">USD - Доллар США</SelectItem>
                          <SelectItem value="EUR">EUR - Евро</SelectItem>
                          <SelectItem value="BTC">BTC - Bitcoin</SelectItem>
                          <SelectItem value="ETH">ETH - Ethereum</SelectItem>
                          <SelectItem value="USDT">USDT - Tether</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <Button onClick={handleAddAccount} disabled={isAddingAccount} className="w-full">
                      {isAddingAccount && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                      Добавить счет
                    </Button>
                  </div>
                </DialogContent>
              </Dialog>
            </div>
          </CardHeader>
          <CardContent>
            {accounts.length === 0 ? (
              <div className="text-center py-8">
                <p className="text-muted-foreground">У вас пока нет привязанных счетов</p>
              </div>
            ) : (
              <div className="space-y-4">
                {accounts.map((account) => (
                  <div
                    key={account.id}
                    className="flex items-center justify-between p-4 border rounded-lg"
                  >
                    <div className="flex items-center space-x-4">
                      {getAccountIcon(account.account_type)}
                      <div>
                        <h4 className="font-medium">{account.account_name}</h4>
                        <p className="text-sm text-muted-foreground">
                          {account.account_number && `${account.account_number} • `}
                          {account.currency} • Баланс: {account.balance}
                        </p>
                      </div>
                    </div>
                    <Button
                      variant="outline"
                      size="icon"
                      onClick={() => handleDeleteAccount(account.id)}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </TabsContent>

      <TabsContent value="transactions">
        <Card>
          <CardHeader>
            <CardTitle>История операций</CardTitle>
            <CardDescription>
              Ваши последние транзакции и обмены
            </CardDescription>
          </CardHeader>
          <CardContent>
            {transactions.length === 0 ? (
              <div className="text-center py-8">
                <p className="text-muted-foreground">История операций пуста</p>
              </div>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Тип</TableHead>
                    <TableHead>Из</TableHead>
                    <TableHead>В</TableHead>
                    <TableHead>Сумма</TableHead>
                    <TableHead>Статус</TableHead>
                    <TableHead>Дата</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {transactions.map((transaction) => (
                    <TableRow key={transaction.id}>
                      <TableCell>
                        {transaction.transaction_type === "exchange" && "Обмен"}
                        {transaction.transaction_type === "deposit" && "Пополнение"}
                        {transaction.transaction_type === "withdrawal" && "Вывод"}
                      </TableCell>
                      <TableCell>{transaction.from_currency}</TableCell>
                      <TableCell>{transaction.to_currency}</TableCell>
                      <TableCell>
                        {transaction.from_amount} → {transaction.to_amount}
                      </TableCell>
                      <TableCell>{getStatusBadge(transaction.status)}</TableCell>
                      <TableCell>
                        {new Date(transaction.created_at).toLocaleDateString("ru-RU")}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </CardContent>
        </Card>
      </TabsContent>

      <TabsContent value="orders">
        <Card>
          <CardHeader>
            <CardTitle>Открытые ордера</CardTitle>
            <CardDescription>
              Ваши активные ордера на обмен по указанному курсу
            </CardDescription>
          </CardHeader>
          <CardContent>
            {openOrders.length === 0 ? (
              <div className="text-center py-8">
                <p className="text-muted-foreground">У вас нет открытых ордеров</p>
              </div>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Из</TableHead>
                    <TableHead>В</TableHead>
                    <TableHead>Сумма</TableHead>
                    <TableHead>Целевой курс</TableHead>
                    <TableHead>Статус</TableHead>
                    <TableHead>Дата создания</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {openOrders.map((order) => (
                    <TableRow key={order.id}>
                      <TableCell>{order.from_currency}</TableCell>
                      <TableCell>{order.to_currency}</TableCell>
                      <TableCell>{order.amount}</TableCell>
                      <TableCell>{order.target_rate}</TableCell>
                      <TableCell>{getStatusBadge(order.status)}</TableCell>
                      <TableCell>
                        {new Date(order.created_at).toLocaleDateString("ru-RU")}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </CardContent>
        </Card>
      </TabsContent>
    </Tabs>
  );
};