import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Users, Gift, TrendingUp } from "lucide-react";

export const PartnerProgramTab = () => {
  return (
    <div className="space-y-6">
      <Card>
        <CardHeader className="text-center">
          <CardTitle className="flex items-center justify-center gap-2 text-2xl">
            <Users className="h-6 w-6" />
            Партнерская программа
          </CardTitle>
          <CardDescription>
            Зарабатывайте вместе с нами, приглашая новых пользователей
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="text-center">
            <div className="mx-auto w-24 h-24 bg-muted rounded-full flex items-center justify-center mb-4">
              <Gift className="h-12 w-12 text-muted-foreground" />
            </div>
            <h3 className="text-xl font-semibold mb-2">Скоро</h3>
            <p className="text-muted-foreground mb-6">
              Мы работаем над запуском партнерской программы. 
              В ближайшее время здесь появится возможность получать комиссию 
              за приглашенных друзей и партнеров.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-4">
            <Card>
              <CardContent className="pt-6 text-center">
                <TrendingUp className="h-8 w-8 mx-auto mb-2 text-primary" />
                <h4 className="font-semibold mb-2">Высокие комиссии</h4>
                <p className="text-sm text-muted-foreground">
                  Получайте до 50% от комиссии с каждой операции ваших рефералов
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="pt-6 text-center">
                <Users className="h-8 w-8 mx-auto mb-2 text-primary" />
                <h4 className="font-semibold mb-2">Многоуровневость</h4>
                <p className="text-sm text-muted-foreground">
                  Зарабатывайте не только с прямых рефералов, но и с их приглашений
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="pt-6 text-center">
                <Gift className="h-8 w-8 mx-auto mb-2 text-primary" />
                <h4 className="font-semibold mb-2">Бонусы</h4>
                <p className="text-sm text-muted-foreground">
                  Дополнительные награды за активность и достижение целей
                </p>
              </CardContent>
            </Card>
          </div>

          <div className="text-center">
            <Button disabled size="lg">
              Присоединиться к программе
            </Button>
            <p className="text-xs text-muted-foreground mt-2">
              Функция будет доступна в ближайшее время
            </p>
          </div>

          <div className="bg-muted/50 p-4 rounded-lg">
            <h4 className="font-semibold mb-2">Что будет доступно:</h4>
            <ul className="space-y-1 text-sm text-muted-foreground">
              <li>• Персональная реферальная ссылка</li>
              <li>• Статистика по приглашенным пользователям</li>
              <li>• История начислений</li>
              <li>• Вывод заработанных средств</li>
              <li>• Маркетинговые материалы</li>
            </ul>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};