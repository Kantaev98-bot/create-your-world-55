import { useState, useEffect } from "react";
import { User } from "@supabase/supabase-js";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { Loader2, Save } from "lucide-react";

interface Profile {
  username: string;
  first_name: string;
  last_name: string;
  middle_name: string;
  phone: string;
  telegram: string;
  document_number: string;
}

interface PersonalDataTabProps {
  user: User;
}

export const PersonalDataTab = ({ user }: PersonalDataTabProps) => {
  const [profile, setProfile] = useState<Profile>({
    username: "",
    first_name: "",
    last_name: "",
    middle_name: "",
    phone: "",
    telegram: "",
    document_number: "",
  });
  const [isLoading, setIsLoading] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    loadProfile();
  }, [user.id]);

  const loadProfile = async () => {
    setIsLoading(true);
    try {
      const { data, error } = await supabase
        .from("profiles")
        .select("*")
        .eq("user_id", user.id)
        .single();

      if (error && error.code !== "PGRST116") {
        console.error("Error loading profile:", error);
        toast({
          variant: "destructive",
          title: "Ошибка",
          description: "Не удалось загрузить профиль",
        });
      } else if (data) {
        setProfile({
          username: data.username || "",
          first_name: data.first_name || "",
          last_name: data.last_name || "",
          middle_name: data.middle_name || "",
          phone: data.phone || "",
          telegram: data.telegram || "",
          document_number: data.document_number || "",
        });
      }
    } catch (error) {
      console.error("Error:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleSave = async () => {
    setIsSaving(true);
    try {
      const { error } = await supabase
        .from("profiles")
        .upsert({
          user_id: user.id,
          ...profile,
        });

      if (error) {
        console.error("Error saving profile:", error);
        toast({
          variant: "destructive",
          title: "Ошибка",
          description: "Не удалось сохранить данные",
        });
      } else {
        toast({
          title: "Успешно!",
          description: "Ваши данные сохранены",
        });
      }
    } catch (error) {
      console.error("Error:", error);
      toast({
        variant: "destructive",
        title: "Ошибка",
        description: "Произошла ошибка при сохранении",
      });
    } finally {
      setIsSaving(false);
    }
  };

  const handleInputChange = (field: keyof Profile, value: string) => {
    setProfile(prev => ({ ...prev, [field]: value }));
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-48">
        <Loader2 className="h-8 w-8 animate-spin" />
      </div>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Личные данные</CardTitle>
        <CardDescription>
          Управляйте своей персональной информацией
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="space-y-2">
          <Label htmlFor="username">Логин</Label>
          <Input
            id="username"
            value={profile.username}
            onChange={(e) => handleInputChange("username", e.target.value)}
            placeholder="Введите логин"
          />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label htmlFor="lastName">Фамилия</Label>
            <Input
              id="lastName"
              value={profile.last_name}
              onChange={(e) => handleInputChange("last_name", e.target.value)}
              placeholder="Введите фамилию"
            />
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="firstName">Имя</Label>
            <Input
              id="firstName"
              value={profile.first_name}
              onChange={(e) => handleInputChange("first_name", e.target.value)}
              placeholder="Введите имя"
            />
          </div>
        </div>

        <div className="space-y-2">
          <Label htmlFor="middleName">Отчество</Label>
          <Input
            id="middleName"
            value={profile.middle_name}
            onChange={(e) => handleInputChange("middle_name", e.target.value)}
            placeholder="Введите отчество"
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="email">Почта</Label>
          <Input
            id="email"
            value={user.email || ""}
            disabled
            className="bg-muted"
          />
          <p className="text-sm text-muted-foreground">
            Для изменения email обратитесь в раздел "Безопасность"
          </p>
        </div>

        <div className="space-y-2">
          <Label htmlFor="phone">Номер телефона</Label>
          <Input
            id="phone"
            value={profile.phone}
            onChange={(e) => handleInputChange("phone", e.target.value)}
            placeholder="+7 (999) 123-45-67"
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="telegram">Telegram</Label>
          <Input
            id="telegram"
            value={profile.telegram}
            onChange={(e) => handleInputChange("telegram", e.target.value)}
            placeholder="@username"
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="documentNumber">Номер удостоверяющего документа</Label>
          <Input
            id="documentNumber"
            value={profile.document_number}
            onChange={(e) => handleInputChange("document_number", e.target.value)}
            placeholder="Серия и номер паспорта"
          />
        </div>

        <Button onClick={handleSave} disabled={isSaving} className="w-full">
          {isSaving && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
          <Save className="mr-2 h-4 w-4" />
          Сохранить изменения
        </Button>
      </CardContent>
    </Card>
  );
};