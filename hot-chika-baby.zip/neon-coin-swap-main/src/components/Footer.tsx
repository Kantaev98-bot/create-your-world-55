import { MessageCircle, Mail, FileText, Shield } from "lucide-react";

export const Footer = () => {
  return (
    <footer id="contact" className="bg-crypto-dark-elevated border-t border-crypto-gray-dark">
      <div className="container mx-auto px-4 py-16">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Company Info */}
          <div className="col-span-1 md:col-span-2">
            <div className="flex items-center space-x-2 mb-6">
              <div className="w-10 h-10 bg-gradient-gold rounded-lg flex items-center justify-center">
                <span className="text-black font-bold text-xl">₿</span>
              </div>
              <span className="text-2xl font-bold text-gradient-gold">CryptoExchange</span>
            </div>
            <p className="text-muted-foreground mb-6 max-w-md">
              Профессиональный обменник криптовалют с индивидуальным подходом. 
              Безопасные и быстрые операции с цифровыми активами.
            </p>
            
            {/* Contact Info */}
            <div className="space-y-4">
              <div className="flex items-center space-x-3">
                <MessageCircle className="w-5 h-5 text-crypto-gold" />
                <a 
                  href="https://t.me/cryptoexchange_support" 
                  className="text-muted-foreground hover:text-crypto-gold transition-colors"
                >
                  @cryptoexchange_support
                </a>
              </div>
              <div className="flex items-center space-x-3">
                <Mail className="w-5 h-5 text-crypto-gold" />
                <a 
                  href="mailto:support@cryptoexchange.ru" 
                  className="text-muted-foreground hover:text-crypto-gold transition-colors"
                >
                  support@cryptoexchange.ru
                </a>
              </div>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-lg font-semibold mb-6">Быстрые ссылки</h3>
            <ul className="space-y-3">
              <li>
                <a href="#exchange" className="text-muted-foreground hover:text-crypto-gold transition-colors">
                  Обмен валют
                </a>
              </li>
              <li>
                <a href="#rates" className="text-muted-foreground hover:text-crypto-gold transition-colors">
                  Курсы валют
                </a>
              </li>
              <li>
                <a href="#about" className="text-muted-foreground hover:text-crypto-gold transition-colors">
                  О компании
                </a>
              </li>
              <li>
                <a href="#contact" className="text-muted-foreground hover:text-crypto-gold transition-colors">
                  Контакты
                </a>
              </li>
            </ul>
          </div>

          {/* Legal */}
          <div>
            <h3 className="text-lg font-semibold mb-6">Документы</h3>
            <ul className="space-y-3">
              <li>
                <a href="/help" className="flex items-center space-x-2 text-muted-foreground hover:text-crypto-gold transition-colors">
                  <FileText className="w-4 h-4" />
                  <span>Помощь</span>
                </a>
              </li>
              <li>
                <a href="/documents" className="flex items-center space-x-2 text-muted-foreground hover:text-crypto-gold transition-colors">
                  <Shield className="w-4 h-4" />
                  <span>Документы</span>
                </a>
              </li>
              <li>
                <a href="/privacy-policy" className="flex items-center space-x-2 text-muted-foreground hover:text-crypto-gold transition-colors">
                  <Shield className="w-4 h-4" />
                  <span>Пользовательское соглашение</span>
                </a>
              </li>
              <li>
                <a href="/warning" className="flex items-center space-x-2 text-muted-foreground hover:text-crypto-gold transition-colors">
                  <FileText className="w-4 h-4" />
                  <span>Предупреждение</span>
                </a>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom Section */}
        <div className="border-t border-crypto-gray-dark mt-12 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="text-sm text-muted-foreground mb-4 md:mb-0">
              © 2024 CryptoExchange. Все права защищены.
            </div>
            <div className="flex items-center space-x-6">
              <div className="text-sm text-muted-foreground">
                Работаем с 2019 года
              </div>
              <div className="w-2 h-2 bg-crypto-success rounded-full animate-pulse"></div>
              <div className="text-sm text-crypto-success font-medium">
                Онлайн 24/7
              </div>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};