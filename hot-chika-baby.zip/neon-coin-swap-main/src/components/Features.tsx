import { Card } from "@/components/ui/card";
import { Shield, Clock, Users, Banknote, Lock, Headphones } from "lucide-react";

const features = [
  {
    icon: Shield,
    title: "Безопасность",
    description: "Многоуровневая система защиты ваших средств и персональных данных",
    color: "text-crypto-gold"
  },
  {
    icon: Clock,
    title: "Быстрые операции",
    description: "Обмен средств происходит в течение 5-15 минут",
    color: "text-crypto-success"
  },
  {
    icon: Users,
    title: "Личный менеджер",
    description: "Персональный подход к каждому клиенту и премиальное обслуживание",
    color: "text-blue-400"
  },
  {
    icon: Banknote,
    title: "Выгодные курсы",
    description: "Лучшие курсы обмена на рынке с минимальными комиссиями",
    color: "text-crypto-gold"
  },
  {
    icon: Lock,
    title: "Анонимность",
    description: "Соблюдение конфиденциальности при проведении операций",
    color: "text-purple-400"
  },
  {
    icon: Headphones,
    title: "24/7 Поддержка",
    description: "Круглосуточная техническая поддержка в Telegram",
    color: "text-crypto-success"
  }
];

export const Features = () => {
  return (
    <section id="about" className="py-20 bg-crypto-pattern">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold mb-4">
            Почему выбирают{" "}
            <span className="text-gradient-gold">нас</span>
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Мы предоставляем профессиональные услуги обмена криптовалют 
            с индивидуальным подходом к каждому клиенту
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <Card 
              key={index}
              className="p-8 bg-card/80 backdrop-blur-sm border-crypto-gray-dark hover-glow group transition-all duration-300"
            >
              <div className="text-center">
                <div className={`w-16 h-16 mx-auto mb-6 rounded-full bg-crypto-dark-elevated flex items-center justify-center group-hover:scale-110 transition-transform`}>
                  <feature.icon className={`w-8 h-8 ${feature.color}`} />
                </div>
                <h3 className="text-xl font-semibold mb-4">{feature.title}</h3>
                <p className="text-muted-foreground leading-relaxed">
                  {feature.description}
                </p>
              </div>
            </Card>
          ))}
        </div>

        {/* Stats Section */}
        <div className="mt-20">
          <Card className="p-8 bg-gradient-dark border-crypto-gray-dark">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
              <div>
                <div className="text-4xl font-bold text-crypto-gold mb-2">50K+</div>
                <div className="text-muted-foreground">Довольных клиентов</div>
              </div>
              <div>
                <div className="text-4xl font-bold text-crypto-gold mb-2">1.2B+</div>
                <div className="text-muted-foreground">Рублей обменено</div>
              </div>
              <div>
                <div className="text-4xl font-bold text-crypto-gold mb-2">5</div>
                <div className="text-muted-foreground">Лет на рынке</div>
              </div>
              <div>
                <div className="text-4xl font-bold text-crypto-gold mb-2">24/7</div>
                <div className="text-muted-foreground">Работаем круглосуточно</div>
              </div>
            </div>
          </Card>
        </div>
      </div>
    </section>
  );
};