import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { useToast } from "@/components/ui/use-toast";
import { Copy, QrCode, CheckCircle, Clock, AlertCircle, MapPin } from "lucide-react";

interface ExchangeData {
  fromCurrency: string;
  toCurrency: string;
  fromAmount: string;
  toAmount: string;
  rate: string;
}

export const ExchangeModal = ({ 
  children, 
  exchangeData 
}: { 
  children: React.ReactNode;
  exchangeData: ExchangeData;
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const [step, setStep] = useState(1);
  const [orderData, setOrderData] = useState({
    phone: "",
    email: "",
    walletAddress: "",
    agreementAccepted: false
  });
  const [orderId] = useState(`CEX${Date.now().toString().slice(-6)}`);
  const [selectedAddress, setSelectedAddress] = useState("");
  const { toast } = useToast();

  // Определяем тип валюты
  const getDestinationType = (currency: string) => {
    const cardCurrencies = ['RUB', 'USD', 'EUR', 'CARD'];
    const cashCurrencies = ['CASH', 'НАЛИЧНЫЕ'];
    
    if (cardCurrencies.includes(currency)) return 'card';
    if (cashCurrencies.includes(currency)) return 'cash';
    return 'crypto';
  };

  const destinationType = getDestinationType(exchangeData.toCurrency);

  // Адреса для наличных
  const cashAddresses = [
    { id: 1, name: "Москва, Красная площадь, 1", district: "ЦАО" },
    { id: 2, name: "Москва, Тверская ул., 12", district: "ЦАО" },
    { id: 3, name: "Москва, Арбат ул., 25", district: "ЦАО" },
    { id: 4, name: "СПб, Невский пр., 28", district: "Центральный" },
    { id: 5, name: "СПб, Литейный пр., 15", district: "Центральный" }
  ];

  const handleSubmitOrder = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!orderData.phone || !orderData.email || !orderData.walletAddress) {
      toast({
        title: "Ошибка",
        description: "Заполните все обязательные поля",
        variant: "destructive",
      });
      return;
    }

    if (!orderData.agreementAccepted) {
      toast({
        title: "Ошибка",
        description: "Примите условия соглашения",
        variant: "destructive",
      });
      return;
    }

    setStep(2);
    toast({
      title: "Заявка создана!",
      description: `Номер заявки: ${orderId}`,
    });
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast({
      title: "Скопировано!",
      description: "Адрес скопирован в буфер обмена",
    });
  };

  const handlePaymentConfirm = () => {
    setStep(3);
    toast({
      title: "Платеж обрабатывается",
      description: "Ожидайте подтверждения операции",
    });
  };

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>
        {children}
      </DialogTrigger>
      <DialogContent className="sm:max-w-lg bg-card border-border max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-gradient-gold">
            {step === 1 && "Создание заявки на обмен"}
            {step === 2 && "Данные для оплаты"}
            {step === 3 && "Статус операции"}
          </DialogTitle>
        </DialogHeader>

        {step === 1 && (
          <form onSubmit={handleSubmitOrder} className="space-y-6">
            {/* Exchange Details */}
            <div className="bg-card/50 rounded-lg p-4 space-y-3">
              <h3 className="font-semibold text-foreground">Детали обмена</h3>
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <span className="text-muted-foreground">Отдаете:</span>
                  <p className="font-medium">{exchangeData.fromAmount} {exchangeData.fromCurrency}</p>
                </div>
                <div>
                  <span className="text-muted-foreground">Получаете:</span>
                  <p className="font-medium text-primary">{exchangeData.toAmount} {exchangeData.toCurrency}</p>
                </div>
              </div>
              <div className="text-sm">
                <span className="text-muted-foreground">Курс: </span>
                <span className="font-medium">1 {exchangeData.fromCurrency} = {exchangeData.rate} {exchangeData.toCurrency}</span>
              </div>
            </div>

            {/* Contact Information */}
            <div className="space-y-4">
              <div>
                <Label htmlFor="phone">Телефон *</Label>
                <Input
                  id="phone"
                  type="tel"
                  placeholder="+7 (999) 999-99-99"
                  value={orderData.phone}
                  onChange={(e) => setOrderData({ ...orderData, phone: e.target.value })}
                  required
                />
              </div>

              <div>
                <Label htmlFor="email">Email *</Label>
                <Input
                  id="email"
                  type="email"
                  placeholder="your@email.com"
                  value={orderData.email}
                  onChange={(e) => setOrderData({ ...orderData, email: e.target.value })}
                  required
                />
              </div>

              {destinationType !== 'cash' && (
                <div>
                  <Label htmlFor="wallet">
                    {destinationType === 'card' 
                      ? `Номер карты для получения (${exchangeData.toCurrency})`
                      : `Введите адрес для получения (${exchangeData.toCurrency})`
                    } *
                  </Label>
                  <Input
                    id="wallet"
                    type="text"
                    placeholder={destinationType === 'card' 
                      ? "Введите номер карты" 
                      : "Введите адрес кошелька"
                    }
                    value={orderData.walletAddress}
                    onChange={(e) => setOrderData({ ...orderData, walletAddress: e.target.value })}
                    required
                  />
                  <p className="text-xs text-muted-foreground mt-1">
                    {destinationType === 'card' 
                      ? "Проверьте номер карты внимательно! Средства будут переведены на указанную карту."
                      : "Проверьте адрес внимательно! Средства будут отправлены на указанный адрес."
                    }
                  </p>
                </div>
              )}

              {destinationType === 'cash' && (
                <div>
                  <Label>Выберите адрес для получения наличных *</Label>
                  <Popover>
                    <PopoverTrigger asChild>
                      <Button 
                        variant="outline" 
                        className="w-full justify-between"
                        type="button"
                      >
                        {selectedAddress || "Выберите адрес для получения"}
                        <MapPin className="w-4 h-4" />
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-full p-0 bg-card border-border">
                      <div className="max-h-64 overflow-y-auto">
                        {cashAddresses.map((address) => (
                          <button
                            key={address.id}
                            className="w-full p-3 text-left hover:bg-accent hover:text-accent-foreground border-b border-border/50 last:border-b-0"
                            onClick={() => {
                              setSelectedAddress(address.name);
                              setOrderData({ ...orderData, walletAddress: address.name });
                            }}
                          >
                            <div className="font-medium">{address.name}</div>
                            <div className="text-sm text-muted-foreground">{address.district}</div>
                          </button>
                        ))}
                      </div>
                    </PopoverContent>
                  </Popover>
                  <p className="text-xs text-muted-foreground mt-1">
                    Выберите удобный для вас адрес получения наличных средств.
                  </p>
                </div>
              )}
            </div>

            {/* Agreement */}
            <label className="flex items-start space-x-3 cursor-pointer">
              <input 
                type="checkbox" 
                className="mt-1 w-4 h-4 accent-primary"
                checked={orderData.agreementAccepted}
                onChange={(e) => setOrderData({ ...orderData, agreementAccepted: e.target.checked })}
                required
              />
              <span className="text-sm text-muted-foreground">
                Я прочитал и согласен с{" "}
                <a href="/privacy-policy" className="text-primary hover:underline">
                  правилами обмена
                </a>{" "}
                и{" "}
                <a href="/privacy-policy" className="text-primary hover:underline">
                  политикой AML/KYC
                </a>
              </span>
            </label>

            <Button type="submit" className="w-full bg-gradient-gold text-black hover:opacity-90">
              Создать заявку
            </Button>
          </form>
        )}

        {step === 2 && (
          <div className="space-y-6">
            {/* Order Info */}
            <div className="bg-card/50 rounded-lg p-4">
              <div className="flex items-center justify-between mb-3">
                <span className="text-sm text-muted-foreground">Номер заявки:</span>
                <span className="font-mono font-medium">{orderId}</span>
              </div>
              <div className="flex items-center space-x-2">
                <Clock className="w-4 h-4 text-yellow-500" />
                <span className="text-sm">Ожидает оплаты</span>
              </div>
            </div>

            {/* Payment Details */}
            <div className="space-y-4">
              <h3 className="font-semibold">Данные для перевода</h3>
              
              {exchangeData.fromCurrency === "RUB" || exchangeData.fromCurrency === "CARD" ? (
                <div className="bg-card/30 rounded-lg p-4 space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-muted-foreground">Карта для перевода:</span>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => copyToClipboard("5536 9140 1234 5678")}
                    >
                      <Copy className="w-4 h-4" />
                    </Button>
                  </div>
                  <p className="font-mono text-lg">5536 9140 1234 5678</p>
                  <p className="text-sm text-muted-foreground">Сбербанк, Иван И.</p>
                  <div className="text-sm">
                    <span className="text-muted-foreground">Сумма к переводу: </span>
                    <span className="font-semibold text-primary">{exchangeData.fromAmount} ₽</span>
                  </div>
                </div>
              ) : (
                <div className="bg-card/30 rounded-lg p-4 space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-muted-foreground">Адрес для перевода:</span>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => copyToClipboard("bc1qxy2kgdygjrsqtzq2n0yrf2493p83kkfjhx0wlh")}
                    >
                      <Copy className="w-4 h-4" />
                    </Button>
                  </div>
                  <p className="font-mono text-sm break-all">bc1qxy2kgdygjrsqtzq2n0yrf2493p83kkfjhx0wlh</p>
                  <div className="text-sm">
                    <span className="text-muted-foreground">Сумма к переводу: </span>
                    <span className="font-semibold text-primary">{exchangeData.fromAmount} {exchangeData.fromCurrency}</span>
                  </div>
                </div>
              )}

              <div className="flex space-x-2">
                <Button variant="outline" className="flex-1">
                  <QrCode className="w-4 h-4 mr-2" />
                  QR-код
                </Button>
                <Button className="flex-1 bg-primary" onClick={handlePaymentConfirm}>
                  Я оплатил
                </Button>
              </div>
            </div>

            {/* Warning */}
            <div className="bg-yellow-500/10 border border-yellow-500/30 rounded-lg p-4">
              <div className="flex items-start space-x-3">
                <AlertCircle className="w-5 h-5 text-yellow-500 flex-shrink-0 mt-0.5" />
                <div className="text-sm">
                  <p className="font-medium text-yellow-400 mb-1">Важно!</p>
                  <ul className="space-y-1 text-muted-foreground">
                    <li>• Переведите точную сумму в течение 30 минут</li>
                    <li>• Не указывайте комментарии к переводу</li>
                    <li>• После оплаты нажмите "Я оплатил"</li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        )}

        {step === 3 && (
          <div className="space-y-6 text-center">
            <div className="w-16 h-16 bg-green-500/20 rounded-full flex items-center justify-center mx-auto">
              <CheckCircle className="w-8 h-8 text-green-500" />
            </div>
            
            <div>
              <h3 className="text-xl font-semibold mb-2">Платеж получен!</h3>
              <p className="text-muted-foreground">
                Ваш платеж обрабатывается. Средства будут переведены на указанный адрес в течение 15-30 минут.
              </p>
            </div>

            <div className="bg-card/50 rounded-lg p-4">
              <div className="text-sm space-y-2">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Заявка:</span>
                  <span className="font-mono">{orderId}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Статус:</span>
                  <span className="text-green-500">Обрабатывается</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">К получению:</span>
                  <span className="font-semibold">{exchangeData.toAmount} {exchangeData.toCurrency}</span>
                </div>
              </div>
            </div>

            <div className="space-y-3">
              <Button 
                variant="outline" 
                className="w-full"
                onClick={() => {
                  copyToClipboard(orderId);
                }}
              >
                <Copy className="w-4 h-4 mr-2" />
                Скопировать номер заявки
              </Button>
              
              <Button 
                className="w-full bg-gradient-gold text-black"
                onClick={() => setIsOpen(false)}
              >
                Закрыть
              </Button>
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
};