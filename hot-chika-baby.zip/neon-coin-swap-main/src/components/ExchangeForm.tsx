import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ExchangeModal } from "@/components/ExchangeModal";
import { ArrowUpDown, Calculator } from "lucide-react";
import { useState } from "react";

const currencyCategories = {
  cash: {
    name: "Наличные",
    currencies: [
      { code: "AED_CASH", name: "Дирхамы", icon: "🇦🇪", rate: 26.5 },
      { code: "RUB_CASH", name: "Рубль", icon: "₽", rate: 1 },
      { code: "USD_CASH", name: "Доллар", icon: "$", rate: 97 },
      { code: "TRY_CASH", name: "Лиры", icon: "₺", rate: 2.85 },
      { code: "TJS_CASH", name: "Сомони", icon: "🇹🇯", rate: 8.9 }
    ]
  },
  sbp_card: {
    name: "СБП/Карта РФ",
    currencies: [
      { code: "SBER", name: "Сбербанк", icon: "🟢", rate: 1 },
      { code: "TINKOFF", name: "Тинькофф", icon: "🟡", rate: 1 },
      { code: "ALPHA", name: "Альфабанк", icon: "🔴", rate: 1 }
    ]
  },
  foreign_card: {
    name: "Карта зарубежная",
    currencies: [
      { code: "CARD_RU", name: "Россия", icon: "🇷🇺", rate: 1 },
      { code: "CARD_AE", name: "ОАЭ", icon: "🇦🇪", rate: 26.5 },
      { code: "CARD_TR", name: "Турция", icon: "🇹🇷", rate: 2.85 },
      { code: "CARD_US", name: "USA", icon: "🇺🇸", rate: 97 },
      { code: "CARD_TJ", name: "Таджикистан", icon: "🇹🇯", rate: 8.9 }
    ]
  },
  bank_details: {
    name: "Реквизиты",
    currencies: [
      { code: "BANK_RU", name: "Россия", icon: "🏦", rate: 1 },
      { code: "BANK_AE", name: "ОАЭ", icon: "🏦", rate: 26.5 },
      { code: "BANK_TR", name: "Турция", icon: "🏦", rate: 2.85 },
      { code: "BANK_US", name: "USA", icon: "🏦", rate: 97 },
      { code: "BANK_TJ", name: "Таджикистан", icon: "🏦", rate: 8.9 }
    ]
  },
  stablecoins: {
    name: "Стейблкоины",
    currencies: [
      { code: "USDT_TRC20", name: "Tether TRC-20", icon: "₮", rate: 96.45 },
      { code: "USDT_BEP20", name: "Tether BEP-20", icon: "₮", rate: 96.45 },
      { code: "USDT_ERC20", name: "Tether ERC-20", icon: "₮", rate: 96.45 }
    ]
  },
  crypto: {
    name: "Крипто",
    currencies: [
      { code: "BTC", name: "Bitcoin", icon: "₿", rate: 2890000 },
      { code: "ETH", name: "Ethereum", icon: "Ξ", rate: 180000 },
      { code: "SOL", name: "Solana", icon: "◎", rate: 5200 }
    ]
  }
};

const getAllCurrencies = () => {
  return Object.values(currencyCategories).flatMap(category => category.currencies);
};

// Функция для определения разрешенных направлений обмена
const isValidExchange = (fromCurrency: string, toCurrency: string) => {
  const fiatTypes = ['cash', 'sbp_card', 'foreign_card', 'bank_details'];
  const cryptoTypes = ['stablecoins', 'crypto'];
  
  const fromCategory = Object.entries(currencyCategories).find(([, category]) => 
    category.currencies.some(c => c.code === fromCurrency)
  )?.[0];
  
  const toCategory = Object.entries(currencyCategories).find(([, category]) => 
    category.currencies.some(c => c.code === toCurrency)
  )?.[0];
  
  if (!fromCategory || !toCategory) return false;
  
  // Проверяем разрешенные направления
  const fromIsFiat = fiatTypes.includes(fromCategory);
  const toIsCrypto = cryptoTypes.includes(toCategory);
  const fromIsCrypto = cryptoTypes.includes(fromCategory);
  const toIsFiat = fiatTypes.includes(toCategory);
  
  return (fromIsFiat && toIsCrypto) || (fromIsCrypto && toIsFiat);
};

const getAvailableToCurrencies = (fromCurrency: string) => {
  return getAllCurrencies().filter(currency => isValidExchange(fromCurrency, currency.code));
};

const getAvailableFromCurrencies = (toCurrency: string) => {
  return getAllCurrencies().filter(currency => isValidExchange(currency.code, toCurrency));
};
  
export const ExchangeForm = () => {
  const [fromCurrency, setFromCurrency] = useState("RUB_CASH");
  const [toCurrency, setToCurrency] = useState("USDT_TRC20");
  const [fromAmount, setFromAmount] = useState("100000");
  const [toAmount, setToAmount] = useState("1036.42");
  const [isAgreementChecked, setIsAgreementChecked] = useState(false);
  const [fromFilter, setFromFilter] = useState<string | null>(null);
  const [toFilter, setToFilter] = useState<string | null>(null);

  const swapCurrencies = () => {
    // Проверяем, возможен ли обратный обмен
    if (isValidExchange(toCurrency, fromCurrency)) {
      setFromCurrency(toCurrency);
      setToCurrency(fromCurrency);
      setFromAmount(toAmount);
      setToAmount(fromAmount);
    }
  };

  const calculateExchange = (amount: string, from: string, to: string) => {
    const allCurrencies = getAllCurrencies();
    const fromRate = allCurrencies.find(c => c.code === from)?.rate || 1;
    const toRate = allCurrencies.find(c => c.code === to)?.rate || 1;
    const result = (parseFloat(amount || "0") / fromRate) * toRate;
    return result.toFixed(2);
  };

  const handleFromAmountChange = (value: string) => {
    setFromAmount(value);
    setToAmount(calculateExchange(value, fromCurrency, toCurrency));
  };

  const handleCurrencyChange = (type: 'from' | 'to', currency: string) => {
    if (type === 'from') {
      setFromCurrency(currency);
      // Проверяем, возможен ли обмен с текущей "to" валютой
      if (!isValidExchange(currency, toCurrency)) {
        // Находим первую доступную валюту для обмена
        const availableTo = getAvailableToCurrencies(currency);
        if (availableTo.length > 0) {
          setToCurrency(availableTo[0].code);
          setToAmount(calculateExchange(fromAmount, currency, availableTo[0].code));
        }
      } else {
        setToAmount(calculateExchange(fromAmount, currency, toCurrency));
      }
    } else {
      // Проверяем, возможен ли обмен с текущей "from" валютой
      if (!isValidExchange(fromCurrency, currency)) {
        // Находим первую доступную валюту для обмена
        const availableFrom = getAvailableFromCurrencies(currency);
        if (availableFrom.length > 0) {
          setFromCurrency(availableFrom[0].code);
          setToCurrency(currency);
          setToAmount(calculateExchange(fromAmount, availableFrom[0].code, currency));
        }
      } else {
        setToCurrency(currency);
        setToAmount(calculateExchange(fromAmount, fromCurrency, currency));
      }
    }
  };

  const getFilteredCategories = (filter: string | null) => {
    if (!filter) return currencyCategories;
    return { [filter]: currencyCategories[filter as keyof typeof currencyCategories] };
  };

  return (
    <section id="exchange" className="py-20 bg-crypto-pattern">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-12">
            <h1 className="text-5xl md:text-6xl font-bold mb-6">
              Обмен{" "}
              <span className="text-gradient-gold">криптовалют</span>
            </h1>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Профессиональный сервис обмена цифровых активов. 
              Быстро, безопасно, выгодно.
            </p>
          </div>

          <Card className="glass-card p-8 hover-glow">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              {/* You Give */}
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="text-lg font-semibold">Отдаете</h3>
                  <div className="flex items-center space-x-2 text-sm text-muted-foreground">
                    <Calculator className="w-4 h-4" />
                    <span>Мин: 5,000 ₽</span>
                  </div>
                </div>
                
                {/* Quick Select Buttons */}
                <div className="grid grid-cols-3 gap-2 mb-6">
                  {Object.entries(currencyCategories).map(([key, category]) => (
                    <Button 
                      key={key}
                      variant={fromFilter === key ? "default" : "outline"}
                      size="sm" 
                      onClick={() => setFromFilter(fromFilter === key ? null : key)}
                      className={`filter-btn h-10 text-xs font-medium relative overflow-hidden ${
                        fromFilter === key 
                          ? 'bg-gradient-gold text-black shadow-gold border-crypto-gold' 
                          : 'bg-crypto-dark-elevated border-crypto-gray-dark hover:border-crypto-gold hover:bg-crypto-gold/10'
                      }`}
                    >
                      {category.name}
                    </Button>
                  ))}
                </div>
                
                <div className="relative group">
                  <Input
                    type="number"
                    value={fromAmount}
                    onChange={(e) => handleFromAmountChange(e.target.value)}
                    className="text-2xl font-bold h-16 pr-32 bg-crypto-dark-elevated/50 border-crypto-gray-dark focus:border-crypto-gold transition-all duration-300 focus:shadow-gold"
                    placeholder="0.00"
                  />
                  <div className="absolute inset-0 pointer-events-none border-2 border-transparent group-focus-within:border-crypto-gold rounded-lg transition-all duration-300"></div>
                  <Select value={fromCurrency} onValueChange={(value) => handleCurrencyChange('from', value)}>
                    <SelectTrigger className="absolute right-2 top-2 w-28 h-12 bg-crypto-dark border-crypto-gray-dark hover:border-crypto-gold transition-all duration-300">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="bg-crypto-dark-elevated border-crypto-gray-dark">
                      {getAllCurrencies().map((currency) => (
                        <SelectItem key={currency.code} value={currency.code}>
                          <div className="flex items-center space-x-2">
                            <span className="text-lg">{currency.icon}</span>
                            <span>{currency.code}</span>
                          </div>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="text-sm text-muted-foreground">
                  {getAllCurrencies().find(c => c.code === fromCurrency)?.name}
                </div>
                
                {/* Currency List */}
                <div className="mt-6 gradient-border rounded-xl p-1">
                  <div className="bg-crypto-dark-elevated rounded-lg p-4 max-h-48 overflow-y-auto">
                    {Object.entries(getFilteredCategories(fromFilter)).map(([key, category]) => (
                      <div key={key} className="mb-4 last:mb-0">
                        <h4 className="text-sm font-semibold text-crypto-gold mb-3 flex items-center">
                          <span className="w-2 h-2 bg-crypto-gold rounded-full mr-2"></span>
                          {category.name}
                        </h4>
                        <div className="space-y-1">
                          {category.currencies.map((currency) => (
                            <Button
                              key={currency.code}
                              variant="ghost"
                              size="sm"
                              onClick={() => handleCurrencyChange('from', currency.code)}
                              className={`currency-item w-full justify-start h-10 text-xs rounded-lg ${
                                fromCurrency === currency.code 
                                  ? 'active' 
                                  : 'hover:bg-crypto-gold/10'
                              }`}
                            >
                              <span className="text-lg mr-3">{currency.icon}</span>
                              <span className="flex-1 text-left font-medium">{currency.name}</span>
                              <span className="text-xs text-crypto-gray-medium font-mono">{currency.code}</span>
                            </Button>
                          ))}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* Swap Button Mobile */}
              <div className="lg:hidden flex justify-center my-8">
                <Button
                  variant="outline"
                  size="icon"
                  onClick={swapCurrencies}
                  className="rounded-full w-14 h-14 border-2 border-crypto-gold bg-crypto-dark hover:bg-crypto-gold hover:text-black transition-all duration-300"
                >
                  <ArrowUpDown className="w-6 h-6" />
                </Button>
              </div>

              {/* You Get */}
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="text-lg font-semibold">Получаете</h3>
                  <div className="flex items-center space-x-2 text-sm text-crypto-success">
                    <span>≈ {toAmount}</span>
                  </div>
                </div>
                
                {/* Quick Select Buttons */}
                <div className="grid grid-cols-3 gap-2 mb-6">
                  {Object.entries(currencyCategories).map(([key, category]) => (
                    <Button 
                      key={key}
                      variant={toFilter === key ? "default" : "outline"}
                      size="sm" 
                      onClick={() => setToFilter(toFilter === key ? null : key)}
                      className={`filter-btn h-10 text-xs font-medium relative overflow-hidden ${
                        toFilter === key 
                          ? 'bg-gradient-gold text-black shadow-gold border-crypto-gold' 
                          : 'bg-crypto-dark-elevated border-crypto-gray-dark hover:border-crypto-gold hover:bg-crypto-gold/10'
                      }`}
                    >
                      {category.name}
                    </Button>
                  ))}
                </div>
                
                <div className="relative group">
                  <Input
                    type="number"
                    value={toAmount}
                    readOnly
                    className="text-2xl font-bold h-16 pr-32 bg-crypto-dark-elevated/50 border-crypto-gray-dark text-crypto-gold cursor-not-allowed"
                    placeholder="0.00"
                  />
                  <div className="absolute inset-0 pointer-events-none border-2 border-crypto-gold/30 rounded-lg"></div>
                  <Select value={toCurrency} onValueChange={(value) => handleCurrencyChange('to', value)}>
                    <SelectTrigger className="absolute right-2 top-2 w-28 h-12 bg-crypto-dark border-crypto-gray-dark hover:border-crypto-gold transition-all duration-300">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="bg-crypto-dark-elevated border-crypto-gray-dark">
                      {getAvailableToCurrencies(fromCurrency).map((currency) => (
                        <SelectItem key={currency.code} value={currency.code}>
                          <div className="flex items-center space-x-2">
                            <span className="text-lg">{currency.icon}</span>
                            <span>{currency.code}</span>
                          </div>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="text-sm text-muted-foreground">
                  {getAllCurrencies().find(c => c.code === toCurrency)?.name}
                </div>
                
                {/* Currency List */}
                <div className="mt-6 gradient-border rounded-xl p-1">
                  <div className="bg-crypto-dark-elevated rounded-lg p-4 max-h-48 overflow-y-auto">
                    {Object.entries(getFilteredCategories(toFilter)).map(([key, category]) => {
                      // Фильтруем валюты, доступные для обмена
                      const availableCurrencies = category.currencies.filter(currency => 
                        isValidExchange(fromCurrency, currency.code)
                      );
                      
                      if (availableCurrencies.length === 0) return null;
                      
                      return (
                        <div key={key} className="mb-4 last:mb-0">
                          <h4 className="text-sm font-semibold text-crypto-gold mb-3 flex items-center">
                            <span className="w-2 h-2 bg-crypto-gold rounded-full mr-2"></span>
                            {category.name}
                          </h4>
                          <div className="space-y-1">
                            {availableCurrencies.map((currency) => (
                              <Button
                                key={currency.code}
                                variant="ghost"
                                size="sm"
                                onClick={() => handleCurrencyChange('to', currency.code)}
                                className={`currency-item w-full justify-start h-10 text-xs rounded-lg ${
                                  toCurrency === currency.code 
                                    ? 'active' 
                                    : 'hover:bg-crypto-gold/10'
                                }`}
                              >
                                <span className="text-lg mr-3">{currency.icon}</span>
                                <span className="flex-1 text-left font-medium">{currency.name}</span>
                                <span className="text-xs text-crypto-gray-medium font-mono">{currency.code}</span>
                              </Button>
                            ))}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              </div>
            </div>

            {/* Exchange Rate */}
            <div className="gradient-border rounded-xl p-1 mb-8">
              <div className="bg-crypto-dark-elevated rounded-lg p-4">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-crypto-gray-medium">Курс обмена:</span>
                  <span className="text-sm font-bold text-crypto-gold">
                    1 {fromCurrency} = {calculateExchange("1", fromCurrency, toCurrency)} {toCurrency}
                  </span>
                </div>
              </div>
            </div>

            {/* Terms */}
            <div className="space-y-4">
              <label className="flex items-start space-x-3 cursor-pointer">
                <input 
                  type="checkbox" 
                  className="mt-1 w-4 h-4 accent-crypto-gold"
                  checked={isAgreementChecked}
                  onChange={(e) => setIsAgreementChecked(e.target.checked)}
                />
                <span className="text-sm text-muted-foreground">
                  Я прочитал и согласен с{" "}
                  <a href="/privacy-policy" className="text-crypto-gold hover:underline">
                    правилами обмена
                  </a>{" "}
                  и{" "}
                  <a href="/privacy-policy" className="text-crypto-gold hover:underline">
                    политикой AML/KYC
                  </a>
                </span>
              </label>
              
              <ExchangeModal
                exchangeData={{
                  fromCurrency,
                  toCurrency,
                  fromAmount,
                  toAmount,
                  rate: calculateExchange("1", fromCurrency, toCurrency)
                }}
              >
                <Button 
                  className="w-full h-16 text-lg font-bold bg-gradient-gold text-black hover:opacity-90 transition-all duration-300 shadow-gold disabled:opacity-50 disabled:cursor-not-allowed"
                  size="lg"
                  disabled={!isAgreementChecked || !fromAmount || parseFloat(fromAmount) < 5000}
                >
                  Создать заявку на обмен
                </Button>
              </ExchangeModal>
            </div>
          </Card>
        </div>
      </div>
    </section>
  );
};