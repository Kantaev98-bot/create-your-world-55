import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { User } from "@supabase/supabase-js";
import { Button } from "@/components/ui/button";
import { 
  Sidebar, 
  SidebarContent, 
  SidebarGroup, 
  SidebarGroupContent, 
  SidebarGroupLabel, 
  SidebarMenu, 
  SidebarMenuButton, 
  SidebarMenuItem,
  useSidebar 
} from "@/components/ui/sidebar";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { User as UserIcon, Settings, CreditCard, Users, LogOut } from "lucide-react";

interface DashboardSidebarProps {
  user: User;
  activeTab: string;
  onTabChange: (tab: string) => void;
}

const dashboardItems = [
  { 
    title: "Личные данные", 
    id: "personal", 
    icon: UserIcon 
  },
  { 
    title: "Безопасность", 
    id: "security", 
    icon: Settings 
  },
  { 
    title: "Финансы", 
    id: "finances", 
    icon: CreditCard 
  },
  { 
    title: "Партнерство", 
    id: "partner", 
    icon: Users 
  },
];

export const DashboardSidebar = ({ user, activeTab, onTabChange }: DashboardSidebarProps) => {
  const { state } = useSidebar();
  const navigate = useNavigate();
  const { toast } = useToast();

  const handleSignOut = async () => {
    try {
      await supabase.auth.signOut();
      toast({
        title: "Выход выполнен",
        description: "Вы успешно вышли из системы",
      });
      navigate("/");
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Ошибка",
        description: "Произошла ошибка при выходе",
      });
    }
  };

  const getMenuClass = (itemId: string) => {
    return activeTab === itemId 
      ? "bg-primary text-primary-foreground" 
      : "hover:bg-muted/50";
  };

  const isCollapsed = state === "collapsed";

  return (
    <Sidebar 
      side="right"
      className={isCollapsed ? "w-14" : "w-64"}
    >
      <SidebarContent>
        <SidebarGroup>
          <SidebarGroupLabel>
            {!isCollapsed && (
              <div className="flex flex-col">
                <span className="font-semibold">Личный кабинет</span>
                <span className="text-xs text-muted-foreground">{user.email}</span>
              </div>
            )}
          </SidebarGroupLabel>
          
          <SidebarGroupContent>
            <SidebarMenu>
              {dashboardItems.map((item) => (
                <SidebarMenuItem key={item.id}>
                  <SidebarMenuButton 
                    onClick={() => onTabChange(item.id)}
                    className={getMenuClass(item.id)}
                  >
                    <item.icon className="h-4 w-4" />
                    {!isCollapsed && <span>{item.title}</span>}
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
              
              <SidebarMenuItem>
                <SidebarMenuButton 
                  onClick={handleSignOut}
                  className="hover:bg-destructive/10 hover:text-destructive"
                >
                  <LogOut className="h-4 w-4" />
                  {!isCollapsed && <span>Выйти</span>}
                </SidebarMenuButton>
              </SidebarMenuItem>
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>
    </Sidebar>
  );
};