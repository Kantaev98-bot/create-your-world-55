import { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { AuthModal } from "./AuthModal";
import { supabase } from "@/integrations/supabase/client";
import { User } from "@supabase/supabase-js";
import { Menu, X, User as UserIcon } from "lucide-react";

export const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [user, setUser] = useState<User | null>(null);
  const navigate = useNavigate();

  useEffect(() => {
    // Check current session
    const checkAuth = async () => {
      const { data: { session } } = await supabase.auth.getSession();
      setUser(session?.user ?? null);
    };

    checkAuth();

    // Listen for auth changes
    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      (event, session) => {
        setUser(session?.user ?? null);
      }
    );

    return () => subscription.unsubscribe();
  }, []);

  return (
    <header className="w-full border-b border-crypto-gray-dark bg-background/95 backdrop-blur-sm sticky top-0 z-50">
      <div className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <div className="flex items-center space-x-2">
            <div className="w-10 h-10 bg-gradient-gold rounded-lg flex items-center justify-center">
              <span className="text-black font-bold text-xl">₿</span>
            </div>
            <span className="text-2xl font-bold text-gradient-gold">CryptoExchange</span>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-8">
            <a href="#exchange" className="text-muted-foreground hover:text-primary transition-colors">
              Обмен
            </a>
            <a href="#rates" className="text-muted-foreground hover:text-primary transition-colors">
              Курсы
            </a>
            <a href="/help" className="text-muted-foreground hover:text-primary transition-colors">
              Помощь
            </a>
            <a href="/documents" className="text-muted-foreground hover:text-primary transition-colors">
              Документы
            </a>
            <a href="/warning" className="text-muted-foreground hover:text-primary transition-colors">
              Предупреждение
            </a>
          </nav>

          {/* Status and Auth Buttons */}
          <div className="hidden md:flex items-center space-x-6">
            {/* Online Status */}
            <div className="flex items-center space-x-2">
              <div className="w-2 h-2 bg-crypto-success rounded-full animate-pulse"></div>
              <div className="text-sm text-crypto-success font-medium">
                Онлайн 24/7
              </div>
            </div>
            {user ? (
              <Button 
                variant="outline" 
                size="sm"
                onClick={() => navigate("/dashboard")}
              >
                <UserIcon className="h-4 w-4 mr-2" />
                Личный кабинет
              </Button>
            ) : (
              <>
                <AuthModal>
                  <Button variant="ghost" size="sm">
                    Войти
                  </Button>
                </AuthModal>
                <AuthModal>
                  <Button variant="default" size="sm" className="bg-gradient-gold text-black hover:opacity-90">
                    Регистрация
                  </Button>
                </AuthModal>
              </>
            )}
          </div>

          {/* Mobile Menu Button */}
          <button
            className="md:hidden p-2"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
          >
            <div className="w-6 h-6 flex flex-col justify-center items-center">
              <div className={`w-full h-0.5 bg-primary transition-all ${isMenuOpen ? 'rotate-45 translate-y-1' : ''}`} />
              <div className={`w-full h-0.5 bg-primary transition-all mt-1 ${isMenuOpen ? 'opacity-0' : ''}`} />
              <div className={`w-full h-0.5 bg-primary transition-all mt-1 ${isMenuOpen ? '-rotate-45 -translate-y-1' : ''}`} />
            </div>
          </button>
        </div>

        {/* Mobile Menu */}
        {isMenuOpen && (
          <div className="md:hidden mt-4 pb-4 border-t border-crypto-gray-dark">
            <nav className="flex flex-col space-y-4 mt-4">
              <a href="#exchange" className="text-muted-foreground hover:text-primary transition-colors">
                Обмен
              </a>
              <a href="#rates" className="text-muted-foreground hover:text-primary transition-colors">
                Курсы
              </a>
              <a href="/help" className="text-muted-foreground hover:text-primary transition-colors">
                Помощь
              </a>
              <a href="/documents" className="text-muted-foreground hover:text-primary transition-colors">
                Документы
              </a>
              <a href="/warning" className="text-muted-foreground hover:text-primary transition-colors">
                Предупреждение
              </a>
              <div className="flex space-x-3 pt-4">
                {user ? (
                  <Button 
                    variant="outline" 
                    size="sm"
                    className="w-full"
                    onClick={() => navigate("/dashboard")}
                  >
                    <UserIcon className="h-4 w-4 mr-2" />
                    Личный кабинет
                  </Button>
                ) : (
                  <>
                    <AuthModal>
                      <Button variant="ghost" size="sm" className="flex-1">
                        Войти
                      </Button>
                    </AuthModal>
                    <AuthModal>
                      <Button variant="default" size="sm" className="flex-1 bg-gradient-gold text-black hover:opacity-90">
                        Регистрация
                      </Button>
                    </AuthModal>
                  </>
                )}
              </div>
            </nav>
          </div>
        )}
      </div>
    </header>
  );
};