import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { AlertTriangle, Shield, Eye, PhoneCall, Lock, CreditCard } from "lucide-react";
import { useToast } from "@/components/ui/use-toast";

const Warning = () => {
  const { toast } = useToast();
  const securityRules = [
    {
      icon: <PhoneCall className="w-6 h-6" />,
      title: "Проверка личности",
      description: "Всегда требуйте подтверждения личности лица, на реквизиты которого вы собираетесь выполнить перевод средств. Сделать это можно посредством личного звонка, либо посредством запроса информации о статусе кошелька оппонента на сайте платежной системы."
    },
    {
      icon: <Eye className="w-6 h-6" />,
      title: "Внимательность при вводе данных",
      description: "Будьте предельно внимательны при заполнении поля «Номер счета» адресата. Допустив ошибку, вы отправляете собственные средства в неизвестном направлении без возможности их возврата."
    },
    {
      icon: <CreditCard className="w-6 h-6" />,
      title: "Осторожность с займами",
      description: "Никогда не предоставляете займы, используя «безотзывные» электронные системы оплаты. В данном случае шанс столкнуться с фактом мошенничества чрезвычайно велик."
    },
    {
      icon: <Shield className="w-6 h-6" />,
      title: "Следование инструкциям",
      description: "Если вам предлагается сделать оплату способом, отличным от указанного в инструкции к использованию нашего сервиса, откажитесь от выполнения платежа и сообщите о случившемся нашему специалисту."
    },
    {
      icon: <Lock className="w-6 h-6" />,
      title: "Избегайте чужих средств",
      description: "Откажитесь от проведения средств, собственниками которых являются третьи лица, через собственные банковские счета. Это может привести к тому, что вы станете соучастником финансового преступления."
    },
    {
      icon: <AlertTriangle className="w-6 h-6" />,
      title: "Проверка информации",
      description: "Всегда уточняйте у сотрудника обменного пункта информацию, приходящую на вашу почту. Проверяйте подлинность всех сообщений."
    }
  ];

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main className="container mx-auto px-4 py-12">
        <div className="max-w-4xl mx-auto">
          {/* Header */}
          <div className="text-center mb-12">
            <div className="w-20 h-20 bg-red-500/20 rounded-full flex items-center justify-center mx-auto mb-6">
              <AlertTriangle className="w-10 h-10 text-red-500" />
            </div>
            <h1 className="text-4xl font-bold text-gradient-gold mb-4">Предупреждение</h1>
            <div className="bg-red-500/10 border border-red-500/30 rounded-lg p-6">
              <p className="text-lg text-red-400 leading-relaxed">
                <strong>Уважаемые клиенты!</strong> Безопасность проведения транзакций может быть поставлена под угрозу, 
                в связи с независящими от нашего сервиса обстоятельствами. Чтобы этого не произошло, рекомендуем 
                ознакомиться со следующими правилами конвертации электронной валюты:
              </p>
            </div>
          </div>

          {/* Security Rules */}
          <div className="space-y-8 mb-12">
            <h2 className="text-2xl font-semibold text-gradient-gold text-center mb-8">Правила безопасности</h2>
            
            {securityRules.map((rule, index) => (
              <div 
                key={index}
                className="bg-card/50 backdrop-blur-sm rounded-lg p-6 border border-border hover:border-red-500/50 transition-all duration-300"
              >
                <div className="flex items-start space-x-4">
                  <div className="w-12 h-12 bg-red-500/20 rounded-lg flex items-center justify-center text-red-500 flex-shrink-0">
                    {rule.icon}
                  </div>
                  <div>
                    <h3 className="text-lg font-semibold text-foreground mb-2">{rule.title}</h3>
                    <p className="text-muted-foreground leading-relaxed">{rule.description}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Important Notice */}
          <div className="bg-card/30 backdrop-blur-sm rounded-lg p-8 border border-border mb-12">
            <div className="flex items-start space-x-4">
              <div className="w-12 h-12 bg-yellow-500/20 rounded-lg flex items-center justify-center text-yellow-500 flex-shrink-0">
                <AlertTriangle className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-xl font-semibold text-gradient-gold mb-4">Важное уведомление</h3>
                <div className="space-y-4 text-muted-foreground">
                  <p>
                    Наш и подобные сервисы <strong className="text-foreground">не предоставляют займов</strong>, 
                    <strong className="text-foreground"> не берут средства у пользователей в долг или под проценты</strong>, 
                    <strong className="text-foreground"> не принимают пожертвований</strong>.
                  </p>
                  <p>
                    При получении сообщений подозрительного характера от нашего имени с похожих на наши либо иных реквизитов, 
                    воздержитесь от выполнения указанных там требований и сообщите о произошедшем в нашу службу поддержки.
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Contact Support */}
          <div className="text-center bg-gradient-to-r from-primary/10 to-red-500/10 rounded-lg p-8 border border-border">
            <h3 className="text-2xl font-semibold text-gradient-gold mb-4">Обнаружили подозрительную активность?</h3>
            <p className="text-muted-foreground mb-6 max-w-2xl mx-auto">
              Если вы столкнулись с подозрительными сообщениями или мошенническими попытками от имени нашего сервиса, 
              немедленно свяжитесь с нашей службой безопасности.
            </p>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
              <div className="flex flex-col items-center space-y-2">
                <div className="w-12 h-12 bg-primary/20 rounded-lg flex items-center justify-center">
                  <span className="text-2xl">📱</span>
                </div>
                <span className="font-medium">Telegram</span>
                <span className="text-sm text-primary">@crypto_support</span>
              </div>
              <div className="flex flex-col items-center space-y-2">
                <div className="w-12 h-12 bg-primary/20 rounded-lg flex items-center justify-center">
                  <span className="text-2xl">📧</span>
                </div>
                <span className="font-medium">Email</span>
                <span className="text-sm text-primary">security@cryptoexchange.ru</span>
              </div>
              <div className="flex flex-col items-center space-y-2">
                <div className="w-12 h-12 bg-primary/20 rounded-lg flex items-center justify-center">
                  <span className="text-2xl">⏰</span>
                </div>
                <span className="font-medium">Время работы</span>
                <span className="text-sm text-muted-foreground">24/7</span>
              </div>
            </div>

            <button 
              className="bg-red-500 hover:bg-red-600 text-white font-medium py-3 px-8 rounded-lg transition-colors"
              onClick={() => {
                toast({
                  title: "Сообщение отправлено",
                  description: "Спасибо за обращение! Мы рассмотрим вашу заявку.",
                });
              }}
            >
              Сообщить о нарушении
            </button>
          </div>

          {/* Footer Message */}
          <div className="text-center mt-12 p-6 bg-card/20 rounded-lg border border-border">
            <p className="text-lg text-gradient-gold font-medium">
              С заботой о вашем финансовом благополучии.
            </p>
            <p className="text-muted-foreground mt-2">
              Команда CryptoExchange
            </p>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default Warning;