import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { Search, HelpCircle, MessageCircle, BookOpen, Shield, CreditCard, Smartphone, Clock } from "lucide-react";
import { useState } from "react";
import { useToast } from "@/components/ui/use-toast";

const Help = () => {
  const [searchQuery, setSearchQuery] = useState("");
  const { toast } = useToast();

  const faqItems = [
    {
      question: "Как начать пользоваться сервисом?",
      answer: "Для начала работы с CryptoExchange необходимо пройти простую регистрацию, указав email и создав пароль. После подтверждения email вы сможете создавать заявки на обмен."
    },
    {
      question: "Какие криптовалюты поддерживаются?",
      answer: "Мы поддерживаем основные криптовалюты: Bitcoin (BTC), Ethereum (ETH), Tether (USDT), Bitcoin Cash (BCH), Litecoin (LTC), Ripple (XRP) и многие другие. Полный список доступен на главной странице."
    },
    {
      question: "Сколько времени занимает обмен?",
      answer: "Время обмена зависит от выбранных валют и загруженности сети. Обычно операции завершаются в течение 15-30 минут после получения средств."
    },
    {
      question: "Какие комиссии взимаются?",
      answer: "Комиссии варьируются от 0.5% до 3% в зависимости от направления обмена и суммы операции. Точная комиссия отображается перед подтверждением заявки."
    },
    {
      question: "Нужна ли верификация?",
      answer: "Для операций до 15,000 рублей в сутки верификация не требуется. Для больших сумм необходимо пройти процедуру подтверждения личности."
    },
    {
      question: "Как связаться с поддержкой?",
      answer: "Служба поддержки работает 24/7. Вы можете написать нам в Telegram @crypto_support, отправить email на support@cryptoexchange.ru или воспользоваться чатом на сайте."
    }
  ];

  const quickActions = [
    {
      icon: <CreditCard className="w-6 h-6" />,
      title: "Создать заявку",
      description: "Быстрый обмен криптовалют",
      action: () => {
        window.location.href = "/#exchange";
      }
    },
    {
      icon: <Smartphone className="w-6 h-6" />,
      title: "Мобильное приложение",
      description: "Скачать приложение для смартфона",
      action: () => {
        toast({
          title: "Скоро!",
          description: "Мобильное приложение находится в разработке",
        });
      }
    },
    {
      icon: <Shield className="w-6 h-6" />,
      title: "Безопасность",
      description: "Узнать о мерах защиты",
      action: () => {
        window.location.href = "/warning";
      }
    },
    {
      icon: <Clock className="w-6 h-6" />,
      title: "Статус заявки",
      description: "Проверить статус операции",
      action: () => {
        const orderId = prompt("Введите номер заявки:");
        if (orderId) {
          toast({
            title: "Поиск заявки",
            description: `Ищем заявку ${orderId}...`,
          });
        }
      }
    }
  ];

  const categories = [
    {
      icon: <BookOpen className="w-8 h-8" />,
      title: "Руководство пользователя",
      description: "Пошаговые инструкции по работе с сервисом",
      articles: 12
    },
    {
      icon: <Shield className="w-8 h-8" />,
      title: "Безопасность и защита",
      description: "Как защитить свои средства и аккаунт",
      articles: 8
    },
    {
      icon: <CreditCard className="w-8 h-8" />,
      title: "Платежи и комиссии",
      description: "Информация о тарифах и способах оплаты",
      articles: 6
    },
    {
      icon: <MessageCircle className="w-8 h-8" />,
      title: "Техническая поддержка",
      description: "Решение технических проблем",
      articles: 15
    }
  ];

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main className="container mx-auto px-4 py-12">
        <div className="max-w-6xl mx-auto">
          {/* Hero Section */}
          <div className="text-center mb-12">
            <h1 className="text-4xl font-bold text-gradient-gold mb-4">Центр помощи</h1>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto mb-8">
              Найдите ответы на ваши вопросы или обратитесь в службу поддержки
            </p>

            {/* Search */}
            <div className="max-w-2xl mx-auto relative">
              <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-muted-foreground w-5 h-5" />
              <input
                type="text"
                placeholder="Поиск по базе знаний..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-12 pr-4 py-4 bg-card/50 backdrop-blur-sm rounded-lg border border-border focus:border-primary focus:outline-none transition-colors text-lg"
              />
            </div>
          </div>

          {/* Quick Actions */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-16">
            {quickActions.map((action, index) => (
              <div 
                key={index}
                className="bg-card/50 backdrop-blur-sm rounded-lg p-6 border border-border hover:border-primary/50 transition-all duration-300 hover:shadow-lg hover:shadow-primary/20 cursor-pointer"
              >
                <div className="w-12 h-12 bg-gradient-gold/20 rounded-lg flex items-center justify-center text-primary mb-4">
                  {action.icon}
                </div>
                <h3 className="text-lg font-semibold text-foreground mb-2">{action.title}</h3>
                <p className="text-muted-foreground text-sm mb-4">{action.description}</p>
                <button 
                  className="text-primary font-medium hover:text-primary/80 transition-colors"
                  onClick={action.action}
                >
                  {typeof action.action === 'function' ? 
                    (action.title === "Создать заявку" ? "Перейти к обмену" :
                     action.title === "Мобильное приложение" ? "Скачать" :
                     action.title === "Безопасность" ? "Подробнее" : "Проверить") + " →" :
                    action.action + " →"
                  }
                </button>
              </div>
            ))}
          </div>

          {/* Categories */}
          <div className="mb-16">
            <h2 className="text-3xl font-bold text-gradient-gold mb-8 text-center">Категории помощи</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              {categories.map((category, index) => (
                <div 
                  key={index}
                  className="bg-card/50 backdrop-blur-sm rounded-lg p-8 border border-border hover:border-primary/50 transition-all duration-300 hover:shadow-lg hover:shadow-primary/20 cursor-pointer"
                >
                  <div className="flex items-start space-x-4">
                    <div className="w-16 h-16 bg-gradient-gold/20 rounded-lg flex items-center justify-center text-primary flex-shrink-0">
                      {category.icon}
                    </div>
                    <div className="flex-1">
                      <h3 className="text-xl font-semibold text-foreground mb-2">{category.title}</h3>
                      <p className="text-muted-foreground mb-3">{category.description}</p>
                      <span className="text-sm text-primary">{category.articles} статей</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* FAQ */}
          <div className="mb-16">
            <h2 className="text-3xl font-bold text-gradient-gold mb-8 text-center">Часто задаваемые вопросы</h2>
            <div className="space-y-4">
              {faqItems.map((item, index) => (
                <div 
                  key={index}
                  className="bg-card/50 backdrop-blur-sm rounded-lg border border-border overflow-hidden"
                >
                  <div className="p-6">
                    <div className="flex items-center space-x-3 mb-3">
                      <HelpCircle className="w-5 h-5 text-primary flex-shrink-0" />
                      <h3 className="text-lg font-semibold text-foreground">{item.question}</h3>
                    </div>
                    <p className="text-muted-foreground leading-relaxed pl-8">{item.answer}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Contact Support */}
          <div className="bg-card/30 backdrop-blur-sm rounded-lg p-8 border border-border text-center">
            <h2 className="text-2xl font-semibold text-gradient-gold mb-4">Не нашли ответ?</h2>
            <p className="text-muted-foreground mb-6 max-w-2xl mx-auto">
              Наша служба поддержки работает круглосуточно и готова помочь вам с любыми вопросами
            </p>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="flex flex-col items-center space-y-2">
                <MessageCircle className="w-8 h-8 text-primary" />
                <span className="font-medium">Онлайн-чат</span>
                <span className="text-sm text-muted-foreground">Ответ в течение 2 минут</span>
              </div>
              <div className="flex flex-col items-center space-y-2">
                <span className="text-2xl">📧</span>
                <span className="font-medium">Email</span>
                <span className="text-sm text-muted-foreground">support@cryptoexchange.ru</span>
              </div>
              <div className="flex flex-col items-center space-y-2">
                <span className="text-2xl">📱</span>
                <span className="font-medium">Telegram</span>
                <span className="text-sm text-muted-foreground">@crypto_support</span>
              </div>
            </div>
            <button 
              className="mt-6 bg-gradient-gold text-black font-medium py-3 px-8 rounded-lg hover:opacity-90 transition-opacity"
              onClick={() => {
                toast({
                  title: "Поддержка",
                  description: "Перенаправление в Telegram...",
                });
                window.open("https://t.me/crypto_support", "_blank");
              }}
            >
              Связаться с поддержкой
            </button>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default Help;