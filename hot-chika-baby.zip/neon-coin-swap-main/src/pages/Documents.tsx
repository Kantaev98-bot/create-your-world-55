import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { FileText, Download, Shield, Scale } from "lucide-react";
import { useToast } from "@/components/ui/use-toast";

const Documents = () => {
  const { toast } = useToast();
  const documents = [
    {
      title: "Пользовательское соглашение",
      description: "Основные правила и условия использования сервиса CryptoExchange",
      icon: <FileText className="w-6 h-6" />,
      type: "PDF",
      size: "248 KB",
      date: "15.12.2024"
    },
    {
      title: "Политика конфиденциальности",
      description: "Правила обработки и защиты персональных данных пользователей",
      icon: <Shield className="w-6 h-6" />,
      type: "PDF", 
      size: "156 KB",
      date: "15.12.2024"
    },
    {
      title: "Правила обмена",
      description: "Детальные инструкции по проведению операций обмена криптовалют",
      icon: <Scale className="w-6 h-6" />,
      type: "PDF",
      size: "324 KB", 
      date: "10.12.2024"
    },
    {
      title: "Тарифы и комиссии",
      description: "Актуальная информация о размерах комиссий за различные операции",
      icon: <FileText className="w-6 h-6" />,
      type: "PDF",
      size: "89 KB",
      date: "01.12.2024"
    }
  ];

  const handleDownload = (docTitle: string) => {
    toast({
      title: "Загрузка начата",
      description: `Скачивание документа: ${docTitle}`,
    });
  };

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main className="container mx-auto px-4 py-12">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-12">
            <h1 className="text-4xl font-bold text-gradient-gold mb-4">Документы</h1>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
              Здесь вы можете найти все необходимые документы, регламентирующие работу нашего сервиса
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {documents.map((doc, index) => (
              <div 
                key={index}
                className="bg-card/50 backdrop-blur-sm rounded-lg p-6 border border-border hover:border-primary/50 transition-all duration-300 hover:shadow-lg hover:shadow-primary/20"
              >
                <div className="flex items-start justify-between mb-4">
                  <div className="flex items-center space-x-3">
                    <div className="w-12 h-12 bg-gradient-gold/20 rounded-lg flex items-center justify-center text-primary">
                      {doc.icon}
                    </div>
                    <div>
                      <span className="inline-block px-2 py-1 bg-primary/20 text-primary text-xs rounded font-medium">
                        {doc.type}
                      </span>
                    </div>
                  </div>
                  <button 
                    className="p-2 hover:bg-primary/20 rounded-lg transition-colors"
                    onClick={() => handleDownload(doc.title)}
                  >
                    <Download className="w-5 h-5 text-primary" />
                  </button>
                </div>

                <h3 className="text-xl font-semibold text-foreground mb-2">{doc.title}</h3>
                <p className="text-muted-foreground mb-4 leading-relaxed">{doc.description}</p>

                <div className="flex items-center justify-between text-sm text-muted-foreground">
                  <span>Размер: {doc.size}</span>
                  <span>Обновлено: {doc.date}</span>
                </div>

                <button 
                  className="w-full mt-4 bg-gradient-gold text-black font-medium py-2 px-4 rounded-lg hover:opacity-90 transition-opacity"
                  onClick={() => handleDownload(doc.title)}
                >
                  Скачать документ
                </button>
              </div>
            ))}
          </div>

          <div className="mt-16 bg-card/30 backdrop-blur-sm rounded-lg p-8 border border-border">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div>
                <h2 className="text-2xl font-semibold text-gradient-gold mb-4">Регулярные обновления</h2>
                <p className="text-muted-foreground mb-4">
                  Мы регулярно обновляем наши документы в соответствии с изменениями в законодательстве 
                  и развитием нашего сервиса.
                </p>
                <ul className="space-y-2 text-muted-foreground">
                  <li>• Автоматические уведомления об изменениях</li>
                  <li>• Архив предыдущих версий документов</li>
                  <li>• Детальная история изменений</li>
                </ul>
              </div>

              <div>
                <h2 className="text-2xl font-semibold text-gradient-gold mb-4">Нужна помощь?</h2>
                <p className="text-muted-foreground mb-4">
                  Если у вас возникли вопросы по любому из документов, наша служба поддержки готова помочь.
                </p>
                <div className="space-y-3">
                  <div className="flex items-center space-x-3">
                    <div className="w-2 h-2 bg-primary rounded-full"></div>
                    <span className="text-muted-foreground">Email: support@cryptoexchange.ru</span>
                  </div>
                  <div className="flex items-center space-x-3">
                    <div className="w-2 h-2 bg-primary rounded-full"></div>
                    <span className="text-muted-foreground">Telegram: @crypto_support</span>
                  </div>
                  <div className="flex items-center space-x-3">
                    <div className="w-2 h-2 bg-primary rounded-full"></div>
                    <span className="text-muted-foreground">Время работы: 24/7</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default Documents;