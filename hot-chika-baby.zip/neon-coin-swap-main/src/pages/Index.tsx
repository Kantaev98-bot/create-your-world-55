import { Header } from "@/components/Header";
import { ExchangeForm } from "@/components/ExchangeForm";
import { RatesTable } from "@/components/RatesTable";
import { Features } from "@/components/Features";
import { Footer } from "@/components/Footer";

const Index = () => {
  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main>
        <ExchangeForm />
        <RatesTable />
        <Features />
      </main>
      <Footer />
    </div>
  );
};

export default Index;