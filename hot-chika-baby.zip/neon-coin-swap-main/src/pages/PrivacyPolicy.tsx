import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";

const PrivacyPolicy = () => {
  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main className="container mx-auto px-4 py-12">
        <div className="max-w-4xl mx-auto">
          <h1 className="text-4xl font-bold text-gradient-gold mb-8">Пользовательское соглашение / ППД</h1>
          
          <div className="prose prose-invert max-w-none">
            <div className="bg-card/50 backdrop-blur-sm rounded-lg p-8 space-y-6">
              <p className="text-lg text-muted-foreground leading-relaxed">
                Настоящий документ (далее – правила, пользовательское соглашение) устанавливает правила использования 
                CryptoExchange и становится обязательным для Пользователя с момента акцепта Пользователем условий 
                настоящего договора, а именно – с момента начала использования CryptoExchange.
              </p>

              <p className="text-muted-foreground">
                CryptoExchange является сложным объектом интеллектуальной собственности, в том числе включающей базу данных, 
                CRM-систему, пользовательский интерфейс. CryptoExchange предоставляет Пользователям возможность подачи заявок 
                на обмен криптовалюты, исполняемые Исполнителем на условиях соглашения между Пользователем и Исполнителем.
              </p>

              <div className="bg-card/70 p-6 rounded-lg">
                <h2 className="text-2xl font-semibold text-gradient-gold mb-4">Список терминов</h2>
                
                <div className="space-y-4">
                  <div>
                    <h3 className="text-lg font-semibold text-primary mb-2">Компания</h3>
                    <p className="text-muted-foreground">ООО «CryptoExchange», правообладатель CryptoExchange.</p>
                  </div>

                  <div>
                    <h3 className="text-lg font-semibold text-primary mb-2">Пользователь или клиент</h3>
                    <p className="text-muted-foreground">
                      Физическое лицо, юридическое лицо, зарегистрированное на территории РФ, индивидуальные предприниматель, 
                      либо самозанятый, использующий CryptoExchange.
                    </p>
                  </div>

                  <div>
                    <h3 className="text-lg font-semibold text-primary mb-2">Исполнитель</h3>
                    <p className="text-muted-foreground">
                      Физическое лицо, юридическое лицо, зарегистрированное на территории РФ, индивидуальные предприниматель, 
                      либо самозанятый, использующий CryptoExchange в качестве лица, исполняющего заявки Пользователей на обмен 
                      криптовалют в том числе в соответствии с условиями настоящих правил.
                    </p>
                  </div>

                  <div>
                    <h3 className="text-lg font-semibold text-primary mb-2">Цифровой актив или криптовалюта</h3>
                    <p className="text-muted-foreground">Криптовалюта, не являющаяся цифровым финансовым активом.</p>
                  </div>
                </div>
              </div>

              <div className="bg-card/70 p-6 rounded-lg">
                <h2 className="text-2xl font-semibold text-gradient-gold mb-4">1. Предмет соглашения</h2>
                
                <div className="space-y-3">
                  <p><span className="font-semibold">1.1.</span> Данные правила являются офертой.</p>
                  <p><span className="font-semibold">1.2.</span> Пользователю предоставляется право доступа к CryptoExchange на основании настоящих правил.</p>
                  <p><span className="font-semibold">1.3.</span> Компания предоставляет пользователю доступ к CryptoExchange, посредством предоставления доступа к сайту в сети Интернет.</p>
                  <p><span className="font-semibold">1.4.</span> Пользователь вправе воспользоваться CryptoExchange для размещения заявки о намерении совершения сделки на обмен криптовалют, не являющихся цифровым финансовым активом.</p>
                  <p><span className="font-semibold">1.5.</span> Компания не является участником, организатором, покупателем, продавцом, агентом, комиссионером, либо иным лицом, являющимся стороной в сделке, заключаемой между Пользователем и Исполнителем.</p>
                </div>
              </div>

              <div className="bg-card/70 p-6 rounded-lg">
                <h2 className="text-2xl font-semibold text-gradient-gold mb-4">2. Право использования CryptoExchange</h2>
                <p className="text-muted-foreground">
                  Пользователь вправе использовать функционал CryptoExchange, исключительно посредством взаимодействия через 
                  пользовательский интерфейс с целью подачи заявки на обмен криптовалюты, информирования о ходе исполнения 
                  поданной заявки, иного информирования и осуществления иных действий, не противоречащих правилам и доступным 
                  в функционале пользовательского интерфейса.
                </p>
              </div>

              <div className="bg-card/70 p-6 rounded-lg">
                <h2 className="text-2xl font-semibold text-gradient-gold mb-4">3. Запрещенные действия</h2>
                
                <div className="space-y-3">
                  <p><span className="font-semibold">3.1.</span> Подделывать коммуникационные потоки, платежные документы или оказывать иное воздействие на CryptoExchange, с целью ухудшить работу CryptoExchange.</p>
                  <p><span className="font-semibold">3.2.</span> Взаимодействовать с CryptoExchange минуя пользовательский интерфейс, либо иным образом пытаясь нарушить его нормальную работу.</p>
                  <p><span className="font-semibold">3.3.</span> Пытаться получить несанкционированный доступ к личной информации другого Пользователя любым способом.</p>
                  <p><span className="font-semibold">3.4.</span> Предпринимать действия, направленные на нарушение нормального функционирования, обход технических ограничений CryptoExchange.</p>
                  <p><span className="font-semibold">3.5.</span> Загружать и использовать на CryptoExchange вредоносные программы, использовать автоматические скрипты.</p>
                </div>
              </div>

              <div className="bg-card/70 p-6 rounded-lg">
                <h2 className="text-2xl font-semibold text-gradient-gold mb-4">4. Регистрация и авторизация</h2>
                <p className="text-muted-foreground">
                  Пользователь может зарегистрироваться на CryptoExchange посредством пользовательского интерфейса, 
                  выполняя алгоритм действий, предусмотренных пользовательским интерфейсом и получив данные для входа 
                  в профиль Пользователя.
                </p>
              </div>
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default PrivacyPolicy;